#include<iostream>
using namespace std;
int main()
{
	int a;//Stores the value in a
	int b;//Stores the value in b
	int *p=&a;//Stores the address of 'a'
	int *q=&b;//Stores the address of 'b'
	int **r=&p;//Stores the address of pointer 'p'
	int **t=&q;//Stores the address of pointer 'q'
	cout<<"Enter value of first number: "<<endl;
	cin>>a;//Inputs the value in a
	cout<<"Enter value of second number: "<<endl;
	cin>>b;//Inputs the value in b
	cout<<"Value of a:"<<a<<endl;//Prints the value of a
	cout<<"Value of b:"<<b<<endl;//Prints the value of b
	cout<<"Value of **r:"<<**r<<endl;// Prints the value pointed by the pointer to pointer 'r' which is the value of 'a'
	cout<<"Value of **t:"<<**t<<endl;// Prints the value pointed by the pointer to pointer 't' which is the value of 'b'
	return 0;
}
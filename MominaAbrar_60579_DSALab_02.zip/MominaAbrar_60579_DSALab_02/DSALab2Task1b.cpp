#include<iostream>
using namespace std;
int main()
{
	int a=5;
	char b='x';
	double c=3.1;
	float d=3.5;
	void *ptr;
	ptr=&a;
	cout<<"Value of a: "<<*(int*)ptr<<endl;
	ptr=&b;
	cout<<"Value of b: "<<*(char*)ptr<<endl;
	ptr=&c;
	cout<<"Value of c: "<<*(double*)ptr<<endl;
	ptr=&d;
	cout<<"Value of d: "<<*(float*)ptr<<endl;
	return 0;
}
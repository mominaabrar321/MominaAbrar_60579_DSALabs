#include<iostream>
using namespace std;
int main()
{
	int *ptr=NULL;
	int num;
	cout<<"Enter a number: ";
	cin>>num;
	if (num!=NULL)
	{
	ptr=&num;
	cout<<"Value of the pointer: "<<*ptr<<endl;
	}
	else
	cout<<"Number is null."<<endl;
	return 0;
}
#include<iostream>
using namespace std;
struct Node
{
    int data;
    Node* next;
    Node(int value)
	{
        data=value;
        next=nullptr;
    }
};
void insertEnd(Node*& head,int value)
{
    Node* newNode=new Node(value);
    if(!head)
	{
        head=newNode;
    }
	else
	{
        Node* temp=head;
        while(temp->next)
		{
            temp=temp->next;
        }
        temp->next=newNode;
    }
}
int totalRainfall(Node* head)
{
    int total=0;
    while(head)
	{
        total+=head->data;
        head=head->next;
    }
    return total;
}
void findMinMax(Node* head,int& minVal,int& maxVal,int& minDay,int& maxDay)
{
    minVal=maxVal=head->data;
    minDay=maxDay=1;
    int day=1;
    while(head)
	{
        if(head->data>maxVal)
		{
            maxVal=head->data;
            maxDay=day;
        }
        if(head->data<minVal)
		{
            minVal=head->data;
            minDay=day;
        }
        head=head->next;
        day++;
    }
}
int getAfter5th(Node* head)
{
    for(int i=0;i<5 && head;i++)
	{
        head=head->next;
    }
    if(head)
	{
    return head->data;
	}
	else
	{
	return -1;
	}
}
int main()
{
    Node* head=nullptr;
    int rainfall;
    cout<<"Enter rainfall for 7 days:\n";
    for(int i=1;i<=7;i++)
	{
        do
		{
            cout<<"Day "<<i<<": ";
            cin>>rainfall;
            if(rainfall<0)
			{
                cout<<"Invalid input! Enter a non-negative number.\n";
            }
        }
		while(rainfall<0);
        insertEnd(head,rainfall);
    }
    int total=totalRainfall(head);
    double average=total/7.0;
    int minVal,maxVal,minDay,maxDay;
    findMinMax(head,minVal,maxVal,minDay,maxDay);
    int after5th=getAfter5th(head);
    cout<<"Total rainfall for the week: "<<total<<"\n";
    cout<<"Average weekly rainfall: "<<average<<"\n";
    cout<<"Highest rainfall on day "<<maxDay<<" with "<<maxVal<<"mm\n";
    cout<<"Lowest rainfall on day "<<minDay<<" with "<<minVal<<"mm\n";
    if(after5th!=-1)
	{
        cout<<"Rainfall of day after 5th node: "<<after5th<<"mm\n";
    }
	else
	{
        cout<<"No data available after the 5th day.\n";
    }
    return 0;
}
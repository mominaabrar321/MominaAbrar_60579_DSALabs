#include<iostream>
using namespace std;
struct Node
{
    int data;
    Node* prev;
    Node* next;
};
void InsertAtBeginning(Node*& head,int data)
{
    Node* newNode=new Node;
    newNode->data=data;
    newNode->prev=NULL;
    newNode->next=head;
    if(head!=NULL)
	{
        head->prev=newNode;
    }
    head=newNode;
}
void InsertAfterValue45(Node*& head,int data)
{
    Node* temp=head;
    while(temp!=NULL)
	{
        if(temp->data==45)
		{
            Node* newNode=new Node;
            newNode->data=data;
            newNode->next=temp->next;
            newNode->prev=temp;
            if(temp->next!=NULL)
			{
                temp->next->prev=newNode;
            }
            temp->next=newNode;
            return;
        }
        temp=temp->next;
    }
    cout<<"Value 45 not found in the list: "<<endl;
}
void display(Node* head)
{
    Node* temp=head;
    while(temp!=NULL)
	{
        cout<<temp->data<<"->";
        temp=temp->next;
    }
    cout<<"NULL: "<<endl;
}
int main()
{
    Node* head=NULL;
    int n,data;
    cout<<"Enter the number of elements: ";
    cin>>n;
    for(int i=0;i<n;i++)
	{
        cout<<"Enter value: ";
        cin>>data;
        InsertAtBeginning(head,data);
    }
    cout<<"Doubly Linked List: ";
    display(head);
    cout<<"Enter value to insert after 45: ";
    cin>>data;
    InsertAfterValue45(head,data);
    cout<<"Updated Doubly Linked List: ";
    display(head);
    return 0;
}